﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadwaveCustomerApi.Data;
using QuadwaveCustomerApi.Dtos;
using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Controllers
{
    [ApiController]
    [Route("api/[Controller]")]
    public class CAddressController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public CAddressController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public ActionResult<CustomerAddressDto> GetAddressById(int id)
        {
            var application = _info.GetAddress(id);
            return Ok(_mapper.Map<CustomerAddressDto>(application));
        }
        //[Route("api/CAddress/getAllCustomerNames")]

        [HttpGet]
        public ActionResult<IEnumerable<CustomerAddressDto>> GetAddresses()
        {
            var acc = _info.GetAddresses();
            return Ok(_mapper.Map<IEnumerable<CustomerAddressDto>>(acc));
        }

        [HttpPost]
        public ActionResult<CustomerAddressDto> CreateAddress(AddressCreateDto addressCreateDto)
        {


            if (addressCreateDto != null)
            {
                var newCust = _mapper.Map<CustomerAddress>(addressCreateDto);
                _info.CreateAddress(newCust);
                return Ok(addressCreateDto);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateAddress(AddressUpdateDto addressUpdateDto, int id)
        {
            var custInDb = _info.GetAddress(id);
            if (custInDb != null)
            {
                _mapper.Map(addressUpdateDto, custInDb);
                _info.UpdateAddress(custInDb);
                //var result = _mapper.Map<CustomerReadDto>(empInDb);
                return Ok();
            }
            else
            {
                return NotFound();
            }           

        }

        [HttpDelete("{id}")]
        public ActionResult DeleteAddress(AddressDeleteDto addressDeleteDto, int id)
        {
            var address = _info.GetAddress(id);
            _mapper.Map(addressDeleteDto, address);

            _info.DeleteAddress(address);
            return Ok();
        }




    }
}
