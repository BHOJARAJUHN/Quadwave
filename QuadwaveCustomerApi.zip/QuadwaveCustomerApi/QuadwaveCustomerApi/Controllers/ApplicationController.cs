﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuadwaveCustomerApi.Data;
using QuadwaveCustomerApi.Dtos;
using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ApplicationController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public ApplicationController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public ActionResult<CustomerReadDto> GetCustomersById(int id)
        {
            var application = _info.GetCustomer(id);
            return Ok(_mapper.Map<CustomerReadDto>(application));
        }


        [HttpGet]

        public ActionResult<IEnumerable<CustomerReadDto>> GetCustomers()
        {
            var application = _info.GetCustomers();
            return Ok(_mapper.Map<IEnumerable<CustomerReadDto>>(application));
        }

        [HttpPost]
        public ActionResult<CustomerReadDto> CreateCustomer(CustomerCreateDto customerCreateDto)
        {


            if (customerCreateDto != null)
            {
                var newCust = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(newCust);
                return Ok(customerCreateDto);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateCustomer(CustomerUpdateDto customerUpdateDto, int id)
        {
            var custInDb = _info.GetCustomer(id);
            if (custInDb != null)
            {
                _mapper.Map(customerUpdateDto, custInDb);
                _info.UpdateCustomer(custInDb);
                //var result = _mapper.Map<CustomerReadDto>(empInDb);
                return Ok();
            }
            else
            {
                return NotFound();
            }

        }

        [HttpDelete("{id}")]
        public ActionResult DeleteCustomer(CustomerDeleteDto customerDeleteDto, int id)
        {
            var customer = _info.GetCustomer(id);
            _mapper.Map(customerDeleteDto, customer);

            _info.DeleteCustomer(customer);
            return Ok();
        }
       
    }
}

