﻿using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Data
{
   public interface ICustomerInfo
    {
        public Customer GetCustomer(int id);
        public List<Customer> GetCustomers();
        
        public Customer CreateCustomer(Customer e);

        public void UpdateCustomer(Customer e);

        public void DeleteCustomer(Customer e);

        //THIS IS FOR CUSTOMER ADDRESS

        public List<CustomerAddress> GetAddresses();
        public CustomerAddress GetAddress(int id);
        public CustomerAddress CreateAddress(CustomerAddress e);
        public void UpdateAddress(CustomerAddress e);
        public void DeleteAddress(CustomerAddress e);




    }
}
