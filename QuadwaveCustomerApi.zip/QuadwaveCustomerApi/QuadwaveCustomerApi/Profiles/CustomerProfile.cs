﻿using AutoMapper;
using QuadwaveCustomerApi.Dtos;
using QuadwaveCustomerApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuadwaveCustomerApi.Profiles
{
    public class CustomerProfile:Profile
    {
        public CustomerProfile()
        {
            CreateMap<CustomerCreateDto, Customer>();
            CreateMap<Customer, CustomerReadDto>();
            CreateMap<CustomerUpdateDto, Customer>();
            CreateMap<CustomerDeleteDto, Customer>();

            CreateMap<CustomerAddress, CustomerAddressDto>(); /*this is Read Dto*/
            CreateMap<AddressCreateDto, CustomerAddress>();
            CreateMap<AddressUpdateDto, CustomerAddress>();
            CreateMap<AddressDeleteDto, CustomerAddress>();


        }
    }
}
