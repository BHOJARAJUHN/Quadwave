import { Component, OnInit } from '@angular/core';
import { Customer } from './Customer.Model';
import { SharedService } from '../shared.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AddEditCustomerComponent } from './add-edit-customer/add-edit-customer.component';
import { EditCustomerComponent } from './edit-customer/edit-customer.component';






@Component({
  selector: 'router-outlet',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit {

  constructor(public service:SharedService,
    private router:Router,
    public dialog: MatDialog
    ) { }
    
  ngOnInit(){
    this.service.refreshList();
   
  }


  openDialog() {
    console.log("caleddd popup-")
    this.dialog.open( AddEditCustomerComponent, {
      height: '500px',
      width: '900px',
      data: { }
    })
  }
  openDialogEdit()
  {
    this.dialog.open( EditCustomerComponent, {
      
      height: '700px',
      width: '900px',
      data: { }
    })
  }

  // onSumbit(form:NgForm)
  // {
  //     if(this.service.formData.CustomerId==0)
  //     this.insertRecord(form);
  //     else
  //     this.updateRecord(form);
  // }
  // insertRecord(form:NgForm)
  // {
  //   this.service.postCustDetails().subscribe(
  //    res=>{
  //       this.resetForm(form);
  //      this.service.refreshList();
  //     },
  //     err=>{console.log(err);}
  //   );
  // }
  // updateRecord(form:NgForm){
  //     this.service.putCustDetails().subscribe(
  //       res=>{
  //         this.resetForm(form);
  //         this.service.refreshList();

  //       }
  //     )
  // }

  deleteRecord(form:NgForm){
    this.service.deleteCustDetails().subscribe
    {
      this.resetForm(form);
      this.service.refreshList();
    }
  }

  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData=new Customer();
  }
}
