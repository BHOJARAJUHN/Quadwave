import {Component, Inject, OnInit} from '@angular/core';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { SharedService } from 'src/app/shared.service';
import { NgForm } from '@angular/forms';
import { Customer } from '../Customer.Model';

export interface DialogData {
  name: string;
}


@Component({
  selector: 'app-add-edit-customer',
  templateUrl: './add-edit-customer.component.html',
  
})

export class AddEditCustomerComponent implements OnInit {
  public currentDate: any;

  ngOnInit() {
     this.currentDate = new Date();
    console.log(this.currentDate)
  }

  constructor(public dialog:MatDialog,public service:SharedService,
    public dialogRef: MatDialogRef<AddEditCustomerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
    ) { }

     onNoClick(): void {
      this.dialogRef.close();
    }

    getCurrentDate() {
      
    }
    onSubmit(form:NgForm){

          this.insertRecord(form);
    }
    insertRecord(form:NgForm)
  {
    this.service.postCustDetails().subscribe(
     res=>{
       // this.resetForm(form);
       this.service.refreshList();
      },
      err=>{console.log(err);}
    );
    }
    // resetForm(form:NgForm){
    //   form.form.reset();
    //   this.service.formData=new Customer();
    // }
}
