import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { SharedService } from 'src/app/shared.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-view-customer',
  templateUrl: './edit-customer.component.html',
  
})
export class EditCustomerComponent implements OnInit {

  constructor(public dialog:MatDialog,public service:SharedService,
    public dialogRef: MatDialogRef<EditCustomerComponent>,
   

    ) { }
  ngOnInit(): void {
  }
  onSave(form:NgForm){
    this.updateRecord(form);
  }
  updateRecord(form:NgForm){
    this.service.putCustDetails().subscribe(
      res=>{
        //this.resetForm(form);
        this.service.refreshList();

      }
    )
}
}
